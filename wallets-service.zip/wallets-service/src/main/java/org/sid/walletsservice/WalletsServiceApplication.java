package org.sid.walletsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalletsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalletsServiceApplication.class, args);
	}

}
