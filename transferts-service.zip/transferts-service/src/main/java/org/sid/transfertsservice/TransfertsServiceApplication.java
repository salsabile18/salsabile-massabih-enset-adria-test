package org.sid.transfertsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransfertsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransfertsServiceApplication.class, args);
	}

}
